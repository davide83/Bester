// DK lang variables contributed by Jan Moelgaard

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Dette er bare en pop-up-skabelon',
template_desc : 'Dette er bare en testknap'
});
