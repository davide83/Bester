// TR lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Genel',
tab_appearance : 'G�r�n��',
tab_advanced : 'Geli�mi�',
general : 'Genel',
title : 'Ba�l�k',
preview : '�nizleme',
constrain_proportions : 'Boyutlar� kilitle',
langdir : 'Dil y�netimi',
langcode : 'Dil kodu',
long_desc : 'Uzun a��klama linki',
style : 'Stil',
classes : 'S�n�flar',
ltr : 'Soldan sa�a',
rtl : 'Sa�dan sola',
id : 'Id',
image_map : 'Resim haritas�(image map)',
swap_image : 'Resmi de�i�tir',
alt_image : 'Alternatif  resim',
mouseover : 'Mouse over i�in',
mouseout : 'Mouse out i�in',
misc : '�e�itli/Di�er',
example_img : 'G�r�n�m&nbsp;�nizleme&nbsp;resim',
missing_alt : 'Resim a��klamas� olmadan devam etmek istedi�inize emin misiniz?'
});