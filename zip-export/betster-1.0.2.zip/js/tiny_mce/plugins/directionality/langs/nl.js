// NL lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Richting links naar rechts',
directionality_rtl_desc : 'Richting rechts naar links'
});
