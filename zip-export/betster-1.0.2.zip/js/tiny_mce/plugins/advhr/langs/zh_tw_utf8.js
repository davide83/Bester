// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com


tinyMCE.addToLang('',{
insert_advhr_desc : '插入或編輯水平線',
insert_advhr_width : '寬',
insert_advhr_size : '高',
insert_advhr_noshade : '無陰影'
});
