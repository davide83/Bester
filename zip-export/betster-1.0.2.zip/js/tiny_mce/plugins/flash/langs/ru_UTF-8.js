// RU lang variables UTF-8

tinyMCE.addToLang('flash',{
title : 'Вставить / Редактировать Flash ролик',
desc : 'Вставить / Редактировать Flash ролик',
file : 'Flash-Файл (.swf)',
size : 'Размер',
list : 'Flash файлы',
props : 'Свойства Flash',
general : 'Основное'
});
