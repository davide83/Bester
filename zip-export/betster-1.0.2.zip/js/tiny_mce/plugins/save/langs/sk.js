/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: sk.js,v 1.1 2007/07/29 17:19:39 borane Exp $ 
 */  

tinyMCE.addToLang('',{
save_desc : 'Uložiť'
});

