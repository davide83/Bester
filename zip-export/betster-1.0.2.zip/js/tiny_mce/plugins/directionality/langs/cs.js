/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/07/29 17:19:34 borane Exp $ 
 */  

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Směr z leva doprava',
directionality_rtl_desc : 'Směr z prava doleva'
});

