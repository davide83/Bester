// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com

tinyMCE.addToLang('',{
directionality_ltr_desc : '由左往右方向',
directionality_rtl_desc : '由右往左方向'
});
