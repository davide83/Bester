// Traduit par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Ins�rer la date',
inserttime_desc : 'Ins�rer l\'heure',
inserttime_months_long : new Array("Janvier", "F�vrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Ao�t", "Septembre", "Octobre", "Novembre", "D�cembre"),
inserttime_months_short : new Array("Jan", "F�v", "Mar", "Avr", "Mai", "Jun", "Jul", "Ao�", "Sep", "Oct", "Nov", "D�c"),
inserttime_day_long : new Array("Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"),
inserttime_day_short : new Array("Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim")
});
