// Canadian French lang variables by Virtuelcom   last modification: 2005-06-15

tinyMCE.addToLang('',{
preview_desc : 'Pr�visualisation'
});
