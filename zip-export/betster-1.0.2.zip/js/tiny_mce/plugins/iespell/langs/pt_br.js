/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Authors : ????
 * Revision and modifications:
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * Last Updated : November 26, 2005
 * TinyMCE Version : 2.0RC4
 */
tinyMCE.addToLang('',{
iespell_desc : 'Executar verifica��o ortogr�fica',
iespell_download : "Verificador ieSpell n�o detectado. Click OK para ir � p�gina de download."
});
