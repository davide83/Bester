// Simplified Chinese lang variables contributed by cube316 (cube316@etang.com)

tinyMCE.addToLang('',{
preview_desc : 'Ԥ��'
});
