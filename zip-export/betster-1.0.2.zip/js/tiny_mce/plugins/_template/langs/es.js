/**
 * ES lang variables
 * 
 * Authors : Alvaro Velasco,
 *           Adolfo Sanz De Diego (asanzdiego) <asanzdiego@yahoo.es>,
 *           Carlos C Soto (eclipxe) <csoto@sia-solutions.com>
 * Last Updated : October 17, 2005
 * TinyMCE Version : 2.0RC3
 */

tinyMCE.addToLang('',{
template_title : 'Esto es solo la plantilla de un popup',
template_desc : 'Esto es solo la plantilla de un bot�n'
});
