// FI lang variables by Tuomo Aura, Ateco.fi

tinyMCE.addToLang('',{
save_desc : 'Tallenna'
});
