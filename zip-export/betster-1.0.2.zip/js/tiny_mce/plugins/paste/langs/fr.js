// Traduit par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('',{
paste_text_desc : 'Coller comme du texte',
paste_text_title : 'Faites CTRL+V pour coller le texte dans la fen�tre.',
paste_text_linebreaks : 'Conserver les retours � la ligne',
paste_word_desc : 'Coller depuis Word',
paste_word_title : 'Faites CTRL+V pour coller le texte dans la fen�tre.',
selectall_desc : 'S�lectionner tout'
});
