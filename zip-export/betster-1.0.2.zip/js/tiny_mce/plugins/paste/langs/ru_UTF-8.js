// RU UTF-8 lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Вставить как простой текст',
paste_text_title : 'Используйте CTRL+V для вставки текста в окошко.',
paste_text_linebreaks : 'Сохранить переносы строк',
paste_word_desc : 'Вставить из Word',
paste_word_title : 'Используйте CTRL+V для вставки текста в окошко.',
selectall_desc : 'Выделить всё'
});
