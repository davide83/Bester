/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/07/29 17:19:56 borane Exp $ 
 */  

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Najdi',
searchreplace_searchnext_desc : 'Najdi znova',
searchreplace_replace_desc : 'Najdi/Nahradit',
searchreplace_notfound : 'Vyhledávaní ukončeno. Řetězec nemusel být nalezen.',
searchreplace_search_title : 'Najdi',
searchreplace_replace_title : 'Najdi/Nahradit',
searchreplace_allreplaced : 'Všechny výskyty řetězce byly změněny.',
searchreplace_findwhat : 'Najít',
searchreplace_replacewith : 'Nahradit',
searchreplace_direction : 'Směr',
searchreplace_up : 'Nahoru',
searchreplace_down : 'Dolů',
searchreplace_case : 'Přesná shoda',
searchreplace_findnext : 'Najdi&nbsp;další',
searchreplace_replace : 'Nahradit',
searchreplace_replaceall : 'Nahradit&nbsp;vše',
searchreplace_cancel : 'Zrušit'
});

