// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('',{
autosave_unload_msg : 'De &aelig;ndringer, du har lavet, vil g&aring; tabt, hvis du lukker denne side.'
});
