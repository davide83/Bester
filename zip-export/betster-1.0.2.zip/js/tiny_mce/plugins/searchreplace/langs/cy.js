// UK lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Canfod',
searchreplace_searchnext_desc : 'Canfod eto',
searchreplace_replace_desc : 'Canfod/Cyfnewid',
searchreplace_notfound : 'Cwblhauwyd y chwilio. Methwyd dod o hyd i\'r testun canfod.',
searchreplace_search_title : 'Canfod',
searchreplace_replace_title : 'Canfod/Cyfnewid',
searchreplace_allreplaced : 'Cyfnewidiwyd holl achosion y testun chwilio.',
searchreplace_findwhat : 'Canfod beth',
searchreplace_replacewith : 'Cyfnewid gyda',
searchreplace_direction : 'Cyfeiriad',
searchreplace_up : 'Fyny',
searchreplace_down : 'Lawr',
searchreplace_case : 'Maint llythrennau\'n bwysig',
searchreplace_findnext : 'Canfod&nbsp;nesaf',
searchreplace_replace : 'Cyfnewid',
searchreplace_replaceall : 'Cyfnewid&nbsp;popeth',
searchreplace_cancel : 'Diddymu',
searchreplace_replace_delta_width : 75
});
