// nn = Norwegian (nynorsk) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
print_desc : 'Skriv ut'
});
