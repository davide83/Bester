// SI lang variables ISO-8859-2

tinyMCE.addToLang('emotions',{
title : 'Vstavi sme&#353;kota',
desc : 'Sme&#353;koti',
cool : 'Kul',
cry : 'Jok',
embarassed : 'Osramo&#269;en',
foot_in_mouth : 'Foot in mouth',
frown : 'Nakrem&#382;en',
innocent : 'Nedol&#382;en',
kiss : 'Poljub',
laughing : 'Smeh',
money_mouth : 'Denar',
sealed : 'Zape&#269;aten',
smile : 'Nasmeh',
surprised : 'Presene&#269;en',
tongue_out : 'Jezik ven',
undecided : 'Neodlo&#269;en',
wink : 'Pome&#382;ik',
yell : 'Kri&#269;im'
});
