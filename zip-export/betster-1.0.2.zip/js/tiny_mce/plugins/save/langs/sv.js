// SV lang variables

tinyMCE.addToLang('save',{
desc : 'Spara'
});
