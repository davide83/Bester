/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/07/29 17:19:40 borane Exp $ 
 */  

tinyMCE.addToLang('',{
save_desc : 'Uložit'
});

