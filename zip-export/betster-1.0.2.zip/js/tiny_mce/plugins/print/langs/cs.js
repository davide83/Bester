/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/07/29 17:19:54 borane Exp $ 
 */  

tinyMCE.addToLang('',{
print_desc : 'Tisk'
});

