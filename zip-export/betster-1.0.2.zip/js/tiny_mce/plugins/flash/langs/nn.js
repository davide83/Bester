// nn = Norwegian (nynorsk) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('flash',{
title : 'Lag/oppdater flash-film',
desc : 'Lag/oppdater flash-film',
file : 'Flash-film (.swf)',
size : 'St&oslash;rrelse',
list : 'Flash-filer',
props : 'Flash egenskaper',
general : 'Generelle innstillinger'
});
