// Traduit par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('',{
fullscreen_title : 'Affichage plein �cran',
fullscreen_desc : 'Affichage plein �cran/normal'
});