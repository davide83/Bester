// UK lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Gludo fel Testun Plaen',
paste_text_title : 'Defnyddia CTRL+V ar dy fysellfwrdd i ludo\'r testun i fewn i\'r ffenest.',
paste_text_linebreaks : 'Cadw toriadau llinell',
paste_word_desc : 'Gludo o Word',
paste_word_title : 'Defnyddia CTRL+V ar dy fysellfwrdd i ludo\'r testun i fewn i\'r ffenest.',
selectall_desc : 'Dewis Popeth'
});
