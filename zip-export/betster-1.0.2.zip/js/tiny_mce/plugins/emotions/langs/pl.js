// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// lemiel 25.10.2005

tinyMCE.addToLang('emotions',{
title : 'Wstaw emotikonk�',
desc : 'Emotikonki',
cool : 'Super',
cry : 'P�acz�',
embarassed : 'Za�enowanie',
foot_in_mouth : 'Trzepi� j�zorem',
frown : 'Marszcz� brew',
innocent : 'Niewinny',
kiss : 'Poca�unek',
laughing : '�miech',
money_mouth : 'Zasady �yciowe',
sealed : 'Zaplombowane usta',
smile : 'U�miech',
surprised : 'Zaskoczenie',
tongue_out : 'Pokazuj� j�zyk',
undecided : 'Niezdecydowanie',
wink : 'Perskie oko',
yell : 'Wycie'
});
