// PL lang variables

tinyMCE.addToLang('',{
save_desc : 'Zachowaj'
});
