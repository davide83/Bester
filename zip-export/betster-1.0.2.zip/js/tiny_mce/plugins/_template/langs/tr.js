// TR lang variables

tinyMCE.addToLang('',{
template_title : 'Bu sadece bir �ablon popup penceresidir',
template_desc : 'Bu sadece bir �ablon butonudur'
});
