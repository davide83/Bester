// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com

tinyMCE.addToLang('emotions',{
title : '插入表情圖示',
desc : '表情圖示',
cool : '酷喔',
cry : '大哭',
embarassed : '好糗呀',
foot_in_mouth : '臭死了',
frown : '哼！懶得理你',
innocent : '我是無辜的',
kiss : '親一個',
laughing : '太可笑嘍',
money_mouth : '好高興喔',
sealed : '閉嘴',
smile : '微笑',
surprised : '驚訝',
tongue_out : '吐舌頭',
undecided : '我想想',
wink : '眨眼',
yell : '衰死了～～'
});
