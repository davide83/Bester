// EN lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'Byddi di\'n colli unrhyw newidiadau os wyt ti\'n gadael y dudalen hon.'
});
