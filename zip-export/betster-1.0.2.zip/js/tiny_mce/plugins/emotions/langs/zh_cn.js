// Simplified Chinese lang variables contributed by tom_cat (thomaswangyang@gmail.com)

tinyMCE.addToLang('emotions',{
title : '�������',
desc : '����',
cool : 'Cool',
cry : 'Cry',
embarassed : 'Embarassed',
foot_in_mouth : 'Foot in mouth',
frown : 'Frown',
innocent : 'Innocent',
kiss : 'Kiss',
laughing : 'Laughing',
money_mouth : 'Money mouth',
sealed : 'Sealed',
smile : 'Smile',
surprised : 'Surprised',
tongue_out : 'Tongue out',
undecided : 'Undecided',
wink : 'Wink',
yell : 'Yell'
});