/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: sk.js,v 1.1 2007/07/29 17:20:39 borane Exp $ 
 */  

tinyMCE.addToLang('',{
autosave_unload_msg : 'Zmeny, ktoré ste urobyl(a) budú stratené, ak opustíte túto stránku.'
});

