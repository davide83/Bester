<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="generator" content="HTML Tidy, see www.w3.org" />
<title>BetSter - Die OpenSource Wett-Software - The OpenSource Bet
Office</title>
<meta http-equiv="Content-Type"
content="text/html; charset=iso-8859-1" />
<meta name="dc.title"       content="" />
<meta name="author"         content="" />
<meta name="dc.creator"     content="" />
<meta name="dc.subject"     content="" />
<meta name="keywords"       content="" />
<meta name="dc.description" content="" />
<meta name="description"    content="" />
<meta name="dc.type"        content="betoffice" />
<meta name="resource-type"  content="document" />
<meta name="dc.format"      scheme="IMT" content="text/html" />

<meta name="dc.coverage"    content="global" />
<meta name="distribution"   content="GLOBAL" /> 
<meta name="dc.rights"      content="" />
<meta name="copyright"      content="GPL" />
<meta name="robots" content="ALL,INDEX,FOLLOW" />
<meta name="revisit-after" content="7 days" />
<link href="/css/style.css" rel="stylesheet" type="text/css" />
<link href="/css/calendar-brown.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="leftlayer" class="left-layer">
<div id="catmenu" class="catmenu">
<p class="menutitle">Categories:</p>

<a href="index.php?cid=0">All Categories (0)</a><br />

</div>

<div id="menu" class="menu">
<p class="menutitle">
Menu: 
</p>
<p>



<a href="/index.php">
Home</a>
<br />

<a href="/highscore.php">

Highscore</a>
<br />

<a href="/archive.php">
Archive</a>
<br />


</p>

<p class="footer"><a href="http://betster.sourceforge.net">BetSter</a></p>


	
</div>
</div>
<div id="mainlayer" class="main-layer">
<h1 class="title">Error</h1>
<p class="title2">A database error occured, please contact the administrator.</p>
<div id="contentlayer" class="content-layer">
<h1>Sorry, no actual Bets</h1>



</div>
</div>
<div class="right-layer">
<div class="user-layer">

<p class="menutitle">Login:</p>
<form name="loginform" action="" method="post"><input type="hidden" name="PHPSESSID" value="2c78f4a67b8066b80a37e0d9cc3aa384" />
<input type="text" value="username" class="login" name="username"  onFocus="javascript:this.value='';" /> <br />
<input type="password" value="password" class="login" name="password"  onFocus="javascript:this.value='';" /> <br />
<input type="submit" name="login" value="LOGIN" class="button" />
</form>
<p class="shortnews"><!-- #ShortNews --><!-- ShortNews# --></p>

<p><a href="create_account.php">New Account</a><br />
<a href="forgot_pwd.php">Forgot password</p>



</div>


</div>
</body>
</html>
