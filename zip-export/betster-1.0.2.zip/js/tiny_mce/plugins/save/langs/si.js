// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
save_desc : 'Shrani'
});
