// TR lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%d-%m-%Y',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Tarihi ekle',
inserttime_desc : 'Zaman� ekle',
inserttime_months_long : new Array("Ocak", "�ubat", "Mart", "Nisan", "May�s", "Haziran", "Temmuz", "A�ustos", "Eyl�l", "Ekim", "Kas�m", "Aral�k"),
inserttime_months_short : new Array("Ock", "�ub", "Mar", "Nis", "May", "Haz", "Tem", "A�u", "Eyl", "Eki", "Kas", "Ara"),
inserttime_day_long : new Array("Pazar", "Pazartesi", "Sal�", "�ar�amba", "Per�embe", "Cuma", "Cumartesi", "Pazar"),
inserttime_day_short : new Array("Paz", "Pzt", "Sal", "�ar", "Per", "Cum", "Cmt", "Paz")
})