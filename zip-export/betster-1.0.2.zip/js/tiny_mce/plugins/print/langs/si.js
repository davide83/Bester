// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
print_desc : 'Natisni'
});
