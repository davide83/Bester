// UK lang variables

tinyMCE.addToLang('',{
save_desc : 'Cadw'
});
