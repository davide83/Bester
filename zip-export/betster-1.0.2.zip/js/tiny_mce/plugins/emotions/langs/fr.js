// Traduit par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('emotions',{
title : 'Choisir une �motic�ne',
desc : 'Ins�rer une �motic�ne',
cool : 'Cool',
cry : 'Triste',
embarassed : 'Embarrass�',
foot_in_mouth : 'Oups !',
frown : 'M�content',
innocent : 'Innocent',
kiss : 'Bisou',
laughing : 'Mort de rire',
money_mouth : 'Sencur�',
sealed : 'Motus',
smile : 'Sourire',
surprised : 'Surprise',
tongue_out : 'Moqueur',
undecided : 'Perplexe',
wink : 'Clin d\'oeil',
yell : 'Horreur !'
});
