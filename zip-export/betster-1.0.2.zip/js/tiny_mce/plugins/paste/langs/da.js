// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('',{
paste_text_desc : 'Inds&aelig;t som ren tekst',
paste_text_title : 'Brug CTRL+V p&aring; tastaturet for at inds&aelig;tte teksten i vinduet.',
paste_text_linebreaks : 'Behold linjebrud',
paste_word_desc : 'Inds&aelig;t fra Word',
paste_word_title : 'Brug CTRL+V p&aring; tastaturet for at inds&aelig;tte teksten i vinduet.',
selectall_desc : 'V&aelig;lg alt'
});
